import IdentityManagement from "./IdentityManagement.json";

export const IDENTITY_CONTRACT_ADDRESS =
  IdentityManagement.networks[11155111].address;
export const IDENTITY_CONTRACT_ABI = IdentityManagement.abi;
