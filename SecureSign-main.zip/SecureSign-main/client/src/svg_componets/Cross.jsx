import React from 'react'

function Cross() {

   


  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="66.667"
      height="66.667"
      version="1"
      viewBox="0 0 50 50"
    >
      <path
        fill="#fcf7f7"
        d="M137 363c-12-12-7-21 37-64l51-49-51-49c-44-43-49-52-37-64s21-7 63 37l49 51 50-49c42-41 52-47 65-37 13 11 8 20-37 62l-52 49 52 49c45 42 50 51 37 62-13 10-23 4-65-37l-50-49-49 51c-42 44-51 49-63 37z"
        transform="matrix(.1 0 0 -.1 0 50)"
      ></path>
    </svg>
  );



  
}

export default Cross